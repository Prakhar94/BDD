package com.walmart.mobility.test.dsl.mobileui.myproductivity;

public enum BasicNameValuePair {

}
