package com.walmart.mobility.test.dsl.mobileui.myproductivity;

import com.qainfotech.ta.framework.pagefactory.MobileWebViewPage;
import com.qainfotech.ta.framework.TestSession;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;
import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.walmart.mobility.test.dsl.mobileui.applications.*;
import com.jcabi.aspects.Loggable;
/**
 *
 * @author Ramandeep <RamandeepSingh@QAInfoTech.com>
 */
@Loggable
public class ApplicationMenu extends MobileWebViewPage{
    
    public ApplicationMenu(TestSession session) throws Exception{
        super(session, "MyProductivity/ApplicationMenu");
    }
    
    public void waitForAppsToLoad(){
        switchToPageContext();
        WebDriverWait wait = new WebDriverWait(session.driver, pageUI.timeout);
        wait.until(ExpectedConditions.invisibilityOfElementLocated(findBy("progressMessage")));
        wait.until(ExpectedConditions.visibilityOf(element("appsList")));
    }
    
    public List<ApplicationLauncher> apps() throws Exception{
        switchToPageContext();
        waitForAppsToLoad();
        List<ApplicationLauncher> appLaunchers = new ArrayList();
        new WebDriverWait(session.driver, 60).until(ExpectedConditions
                .visibilityOfAllElements(elements("appsList")));
        for(WebElement appLauncherContainer:elements("appsList")){
            appLaunchers.add(new ApplicationLauncher(session, appLauncherContainer));
        }
        return appLaunchers;
    }
    
    public Application launchApp(String name) throws Exception{
        for(ApplicationLauncher appLauncher:apps()){
            if(appLauncher.name().equals(name)){
                return appLauncher.launch();
            }
        }
        return null;
    }
    
    public Boolean hasApplication(String name) throws Exception{
        for(ApplicationLauncher appLauncher:apps()){
            if(appLauncher.name().equals(name)){
                return true;
            }
        }
        return false;
    }
    
    public LandingPage signOut() throws Exception{
        switchToPageContext();
        element("signOutLink").click();
        return new LandingPage(session);
    }
}
