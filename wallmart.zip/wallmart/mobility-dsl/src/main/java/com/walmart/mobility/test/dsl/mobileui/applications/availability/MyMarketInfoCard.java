package com.walmart.mobility.test.dsl.mobileui.applications.availability;

import com.walmart.mobility.test.dsl.mobileui.myproductivity.*;
import com.qainfotech.ta.framework.pagefactory.MobileWebViewPage;
import com.qainfotech.ta.framework.TestSession;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.JavascriptExecutor;
import com.jcabi.aspects.Loggable;
import com.walmart.mobility.test.dsl.mobileui.applications.Application;
/**
 *
 * @author Ramandeep <RamandeepSingh@QAInfoTech.com>
 */
@Loggable
public class MyMarketInfoCard extends Application{
    
    WebElement cardContainer; 
    
    public MyMarketInfoCard(TestSession session, WebElement cardContainer) throws Exception{
        super(session, "Applications/Availability/MyMarketInfoCard");
        this.cardContainer = cardContainer;
    }
    
    public String title(){
        return element(cardContainer, "title").getText().trim();
    }
    
    public String score(){
        return element(cardContainer, "marketValue").getText().trim();
    }
}
