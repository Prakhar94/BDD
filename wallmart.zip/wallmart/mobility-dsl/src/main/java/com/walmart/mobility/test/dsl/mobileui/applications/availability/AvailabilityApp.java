package com.walmart.mobility.test.dsl.mobileui.applications.availability;

import com.walmart.mobility.test.dsl.mobileui.myproductivity.*;
import com.qainfotech.ta.framework.pagefactory.MobileWebViewPage;
import com.qainfotech.ta.framework.TestSession;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.jcabi.aspects.Loggable;
import com.walmart.mobility.test.dsl.mobileui.applications.Application;

import java.util.List;
import java.util.ArrayList;

/**
 *
 * @author Ramandeep <RamandeepSingh@QAInfoTech.com>
 */
@Loggable
public class AvailabilityApp extends Application{
    
    public AvailabilityApp(TestSession session) throws Exception{
        super(session, "Applications/Availability/AvailabilityApp");
    }
    
    public MyMarketInfoCard myOSCAScoreCard() throws Exception{
        return new MyMarketInfoCard(session, element("myOSCAScoreCard"));
    }
    
    public List<MyMarketInfoCard> marketCards() throws Exception{
        new WebDriverWait(session.driver, pageUI.timeout).until(
                ExpectedConditions.visibilityOf(element("marketCards"))
        );
        
        List<MyMarketInfoCard> infoCards = new ArrayList();
        for(WebElement cardElement:elements("marketCards")){
            infoCards.add(new MyMarketInfoCard(session, cardElement));
        }
        return infoCards;
    }
    
    public void skipIntro(){
        throbber.waitToComplete();
        switchContext();
        for(WebElement link:elements("links")){
            if(link.getText().equals("Skip Intro")){
                link.click();
                break;
            }
        }
    }
    
    public void toggleMenu(){
        ((JavascriptExecutor)session.driver).executeScript(
                "$(arguments[0]).click()", element("menuIcon"));
    }
    
    public void showMenu(){
        waitForLoading();
        if(!element("menuBar").isDisplayed()){
            toggleMenu();
        }
    }
    
    public void hideMenu(){
        waitForLoading();
        if(element("menuBar").isDisplayed()){
            toggleMenu();
        }
    }
    
    public ApplicationMenu exit() throws Exception{
        showMenu();
        ((JavascriptExecutor)session.driver).executeScript(
                "_.triggerCueme(\"exit\");", element("menuIcon"));
        return new ApplicationMenu(session);
    }
}
