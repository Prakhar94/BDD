package com.walmart.mobility.test.dsl.mobileui.myproductivity;

import org.junit.Assert;
import org.openqa.selenium.JavascriptExecutor;

import com.jcabi.aspects.Loggable;
import com.qainfotech.ta.framework.TestSession;
import com.qainfotech.ta.framework.pagefactory.MobileWebViewPage;

import io.appium.java_client.MobileDriver;
import io.appium.java_client.TouchAction;

@Loggable
public class HRIS_HomePage extends MobileWebViewPage {

	public HRIS_HomePage(TestSession session) throws Exception {
		super(session, "MyProductivity/HRIS_HomePage");
	}
	public void verifyHomePage(){
//		visibleElement("title");
		System.out.println("hello");
//		element("title").isDisplayed();
	}
	
	public void verifyTabs(){
		System.out.println("VerifyTabs");
		
		
	}
	public void clickSideNavButton() throws InterruptedException {

		Thread.sleep(3000);
		System.out.println("55555555555"+element("hrisLogin").getText());
		element("hrisLogin").click();
		/*TouchAction taction = new TouchAction((MobileDriver) session.driver);
		taction.tap(element("hrisLogin")).perform();*/
//	((JavascriptExecutor) session.driver).executeScript("arguments[0].click()", element("hrisLogin"));
	}
	
	public void selectHRISlogin() throws InterruptedException{
		
		elements("SideNavOptions").get(1).click();
	}

}
