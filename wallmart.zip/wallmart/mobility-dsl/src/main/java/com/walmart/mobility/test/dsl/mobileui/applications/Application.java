package com.walmart.mobility.test.dsl.mobileui.applications;

import com.walmart.mobility.test.dsl.mobileui.myproductivity.*;
import com.qainfotech.ta.framework.pagefactory.MobileWebViewPage;
import com.qainfotech.ta.framework.TestSession;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import com.jcabi.aspects.Loggable;
/**
 *
 * @author Ramandeep <RamandeepSingh@QAInfoTech.com>
 */
@Loggable
public class Application extends MobileWebViewPage{
    
    public LoadingThrobber throbber; 
    
    public Application(TestSession session, String specFile) throws Exception{
        super(session, specFile);
        throbber = new LoadingThrobber(session);
    }
    
    public String name(){
        switchToPageContext();
        return session.driver.getTitle();
    }
    
    public void waitForAppToLoad(){
        try{
            Thread.sleep(3000);
        } catch(Exception e){
        }
        switchToPageContext();
        try{
            new WebDriverWait(session.driver, 3).until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".loading-container")));
        }catch(Exception e){}
        try{
            new WebDriverWait(session.driver, 60).until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(".loading-container")));
        }catch(Exception e){}
    }
    
    public void waitForLoading(){
        new WebDriverWait(session.driver, pageUI.timeout).until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(".loading-container")));
    }
//    
//    public void switchToApp() {
//        try{
//            Thread.sleep(3000);
//        } catch(Exception e){
//        }
//        switchContext();
//        for(String handle:session.driver.getWindowHandles()){
//            session.driver.switchTo().window(handle);
//            if(session.driver.getTitle().equals(name)){
//                break;
//            }
//        }
//    }
}
