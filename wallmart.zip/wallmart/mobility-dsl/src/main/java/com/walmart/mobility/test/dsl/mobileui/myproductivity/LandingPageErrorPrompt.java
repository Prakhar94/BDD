package com.walmart.mobility.test.dsl.mobileui.myproductivity;

import com.qainfotech.ta.framework.pagefactory.MobileWebViewPage;
import com.qainfotech.ta.framework.TestSession;
import org.openqa.selenium.By;

import org.openqa.selenium.WebElement;
import com.jcabi.aspects.Loggable;
/**
 *
 * @author Ramandeep <RamandeepSingh@QAInfoTech.com>
 */
@Loggable
public class LandingPageErrorPrompt extends MobileWebViewPage{
    
    public LandingPageErrorPrompt(TestSession session) throws Exception{
        super(session, "MyProductivity/LandingPageErrorPrompt");
    }
    
    public String getMessage(){
        switchToPageContext();
        return element("errorMessage").getText();
    }
    
    public LandingPage confirmPrompt() throws Exception{
        switchToPageContext();
        element("errorPromptConfirmButton").click();
        return new LandingPage(session);
    }
    
}
