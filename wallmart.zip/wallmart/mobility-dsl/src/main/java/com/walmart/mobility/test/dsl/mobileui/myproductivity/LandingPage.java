package com.walmart.mobility.test.dsl.mobileui.myproductivity;

import com.qainfotech.ta.framework.pagefactory.MobileWebViewPage;
import com.qainfotech.ta.framework.TestSession;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import io.appium.java_client.AppiumDriver;
import java.util.List;
import java.util.Map;
import com.jcabi.aspects.Loggable;
import static com.qainfotech.ta.framework.TestDataEncryptor.*;

/**
 *
 * @author Ramandeep <RamandeepSingh@QAInfoTech.com>
 */
@Loggable
public class LandingPage extends MobileWebViewPage{
    
    public ProgressThrobber throbber;
    public LandingPageErrorPrompt errorPrompt;
    
    public LandingPage(TestSession session) throws Exception{
        super(session, "MyProductivity/LandingPage");
        throbber = new ProgressThrobber(session);
        errorPrompt = new LandingPageErrorPrompt(session);
    }
    
    public LandingPageErrorPrompt submitSignInFormWithInvalidCredentials(String userId, 
            String password, String domain, String country, String siteNumber) 
            throws Exception{
        submitSignInForm(userId, password, domain, country, siteNumber);
        switchContext();
        return errorPrompt;
    }
    
    public LandingPageErrorPrompt submitSignInFormWithInvalidCredentials(Map<String, String> creds) 
            throws Exception{
        switchContext();
        submitSignInForm(creds);
        switchContext();
        return errorPrompt;
    }
    
    public ApplicationMenu signInWithValidCredentials(Map<String, String> formData)
            throws Exception{
        return signInWithValidCredentials(formData.get("userId"), 
                formData.get("password"), formData.get("location"), 
                formData.get("country"), formData.get("siteNumber"));
    }

    public ApplicationMenu signInWithValidCredentials(String userId, 
            String password, String domain, String country, String siteNumber) 
            throws Exception{
        submitSignInForm(userId, password, domain, country, siteNumber);
        return new ApplicationMenu(session);
    }
    
    public void submitSignInForm(Map<String, String> formData){
        submitSignInForm(formData.get("userId"), formData.get("password"), 
                formData.get("location"), formData.get("country"), 
                formData.get("siteNumber"));
    }
    
    public void submitSignInForm(String userId, String password, String domain, 
            String country, String siteNumber){
        switchContext();
        throbber.waitToComplete();
        switchToPageContext();
        if(userId!=null){
            element("userIdEntry").clear();
            element("userIdEntry").sendKeys(userId);
        }
        if(password!=null){
            element("passwordEntry").click();
            element("passwordEntry").sendKeys(decrypt(password));
        }
        if(siteNumber!=null){
            element("siteNumberEntry").clear();
            element("siteNumberEntry").sendKeys(siteNumber);
        }
        if(domain!=null){
            selectLocation(domain);
        }
        switchToPageContext();
        if(country!=null){
            selectCountry(country);
        }
        hideKeyboard();
        switchToPageContext();
        element("signInButton").click();
    }
    
    public void selectLocation(String location){
        if(!location.equals("")){
            new Select(element("locationSelectList"))
                    .selectByVisibleText(location);
        }
    }
    
    public void selectCountry(String country){
        if(!country.equals("")){
            new Select(element("countrySelectList"))
                    .selectByVisibleText(country);
        }
    }
    
//    public void selectItemFromList(String itemText){
//        switchToNativeContext();
//        List<WebElement> items = elements("selectListItems");
//        ((AppiumDriver)session.driver).scrollToExact(itemText);
//        for(WebElement item:items){
//            if(item.getText().equals(itemText)){
//                item.click();
//                break;
//            }
//        }
//    }
}
