package com.walmart.mobility.test.dsl.mobileui.myproductivity;

import com.walmart.mobility.test.dsl.mobileui.applications.availability.AvailabilityApp;
import com.qainfotech.ta.framework.pagefactory.MobileWebViewPage;
import com.qainfotech.ta.framework.TestSession;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;

import com.walmart.mobility.test.dsl.mobileui.applications.*;
import com.jcabi.aspects.Loggable;
/**
 *
 * @author Ramandeep <RamandeepSingh@QAInfoTech.com>
 */

@Loggable
public class ApplicationLauncher extends MobileWebViewPage{
    
    public WebElement container;
    
    public ApplicationLauncher(TestSession session, WebElement launcherContainer) throws Exception{
        super(session, "MyProductivity/ApplicationLauncher");
        container = launcherContainer;
    }
    
    public String name(){
        switchToPageContext();
        return element(container,"title").getText();
    }
    
    public String subTitle(){
        switchToPageContext();
        return element(container,"subTitle").getText();
    }
    
    public Application launch() throws Exception{
        switchToPageContext();
        element(container, "openButton").click();
        switch(name()){
            case "Availability":
                AvailabilityApp app = new AvailabilityApp(session);
                app.waitForAppToLoad();
                return app;
        }
        return null;
    }
}
