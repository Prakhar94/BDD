package com.walmart.mobility.test.dsl.mobileui.myproductivity;

import com.qainfotech.ta.framework.pagefactory.MobileWebViewPage;
import com.qainfotech.ta.framework.TestSession;
import org.openqa.selenium.By;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.jcabi.aspects.Loggable;
/**
 *
 * @author Ramandeep <RamandeepSingh@QAInfoTech.com>
 */
@Loggable
public class ProgressThrobber extends MobileWebViewPage{
    
    public ProgressThrobber(TestSession session) throws Exception{
        super(session, "MyProductivity/ProgressThrobber");
    }
    
    public String getMessage(){
        switchContext();
        return element("message").getText();
    }
    
    public void waitTillDisplayed(){
        switchContext();
        WebDriverWait wait = new WebDriverWait(session.driver, pageUI.timeout/2);
        try{
            wait.until(ExpectedConditions.visibilityOfElementLocated(findBy("message")));
        }catch(Exception e){
            // skip error
        }
    }
    
    public void waitToComplete(){
        switchContext();
        waitTillDisplayed();
        WebDriverWait wait = new WebDriverWait(session.driver, pageUI.timeout*6);
        wait.until(ExpectedConditions.invisibilityOfElementLocated(findBy("message")));
    }
    
}
