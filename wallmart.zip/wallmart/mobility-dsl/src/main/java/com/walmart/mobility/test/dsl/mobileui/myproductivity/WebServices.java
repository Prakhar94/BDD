package com.walmart.mobility.test.dsl.mobileui.myproductivity;

import java.io.File;

import org.apache.http.client.methods.HttpPost;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.RestAssured.*;
import com.qainfotech.ta.framework.TestSession;
import com.qainfotech.ta.framework.pagefactory.MobileWebViewPage;

public class WebServices extends MobileWebViewPage {
	public WebServices(TestSession session) throws Exception {
		super(session, "");
	}
	
	String relativePath;
	static String jsonSchemaPathDirectory;
	String output;

	public static void setBaseUrlAndJsonSchemaPath() {
		RestAssured.baseURI = "http://10.0.1.86/snl/";
		jsonSchemaPathDirectory =  System.getProperty("user.dir") + File.separator + "src" + File.separator + "main" + File.separator +
	    		"resources" + File.separator + "jsonSchemas" + File.separator;
	}
	
	public static void getOAUTH2_Token(){
		
		
		
		
		
		
	
	}
	
	

}
