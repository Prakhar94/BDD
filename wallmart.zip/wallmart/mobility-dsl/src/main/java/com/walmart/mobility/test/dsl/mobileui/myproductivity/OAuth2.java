package com.walmart.mobility.test.dsl.mobileui.myproductivity;

import java.io.DataOutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.client.methods.HttpPost;

public class OAuth2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		//Access Token Request
//		URI url = new URI("http://10.0.1.86/snl/oauth/token");
//		HttpPost post = new HttpPost(url);
//        String clientId = "53ec86e0c71ac4531b00ca7dd1119e0e9e4e001d9907a5d2be662baad04fed09";
//        String clientSecret = "fe4fa8581e2e33997bd75738c450e5b147465861839f5d99ff8d43b09d27f9ac";
////        String scope = oauthDetails.getScope();
//        Map<String, String> map = new HashMap<String, String>();
// 
//        List<BasicNameValuePair> parametersBody = new ArrayList<BasicNameValuePair>();
// 
//        parametersBody.add(new BasicNameValuePair(OAuthConstants.GRANT_TYPE,
//                oauthDetails.getGrantType()));
// 
//        parametersBody.add(new BasicNameValuePair(OAuthConstants.CODE,
//                authorizationCode));
// 
//        parametersBody.add(new BasicNameValuePair(OAuthConstants.CLIENT_ID,
//                clientId));
// 
//        if (isValid(clientSecret)) {
//            parametersBody.add(new BasicNameValuePair(
//                    OAuthConstants.CLIENT_SECRET, clientSecret));
//        }
// 
//        parametersBody.add(new BasicNameValuePair(OAuthConstants.REDIRECT_URI,
//                oauthDetails.getRedirectURI()));
// 
//        DefaultHttpClient client = new DefaultHttpClient();
//        HttpResponse response = null;
//        String accessToken = null;
//        try {
//            post.setEntity(new UrlEncodedFormEntity(parametersBody, HTTP.UTF_8));
// 
//            response = client.execute(post);
//            int code = response.getStatusLine().getStatusCode();
// 
//            map = handleResponse(response);
//            accessToken = map.get(OAuthConstants.ACCESS_TOKEN);
// 
//        } catch (ClientProtocolException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//            throw new RuntimeException(e.getMessage());
//        } catch (IOException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//            throw new RuntimeException(e.getMessage());
//        }
// 
//        return map;
		
		
//		String urlParameters  = "param1=a&param2=b&param3=c";
//		byte[] postData       = urlParameters.getBytes( StandardCharsets.UTF_8 );
//		int    postDataLength = postData.length;
//		String request        = "http://example.com/index.php";
//		URL    url            = new URL( request );
//		HttpURLConnection conn= (HttpURLConnection) url.openConnection();           
//		conn.setDoOutput( true );
//		conn.setInstanceFollowRedirects( false );
//		conn.setRequestMethod( "POST" );
//		conn.setRequestProperty( "Content-Type", "application/x-www-form-urlencoded"); 
//		conn.setRequestProperty( "charset", "utf-8");
//		conn.setRequestProperty( "Content-Length", Integer.toString( postDataLength ));
//		conn.setUseCaches( false );
//		try( DataOutputStream wr = new DataOutputStream( conn.getOutputStream())) {
//		   wr.write( postData );
//		}

	}

}
