package com.qainfotech.ta.framework;

//import org.testng.Reporter;
import org.apache.log4j.Logger;


/**
 *
 * @author Ramandeep <RamandeepsSingh@QAInfoTech.com>
 */
public class TestActivityLogger {
    
    Logger coreLogger;
    
    public TestActivityLogger(Logger logger){
        coreLogger = logger;
    }

    public TestActivityLogger(){
        
    }
    
    public void info(String message){
//        Reporter.log("INFO: " + message);
        coreLogger.info(message);
    }
    
    public void error(String message){
//        Reporter.log("ERROR: " + message);
        coreLogger.error(message);
    }
    
    public void debug(String message){
//        Reporter.log("DEBUG: " + message);
        coreLogger.debug(message);
    }
    
    public void warn(String message){
//        Reporter.log("WARN: " + message);
        coreLogger.warn(message);
    }
}
