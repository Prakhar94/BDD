package com.qainfotech.ta.framework.pagefactory;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Map;
import java.util.List;

/**
 *
 * @author Ramandeep <RamandeepsSingh@QAInfoTech.com>
 */
public class SpecFile extends File{
    
    public SpecFile(String yamlFile, YamlPage pageUI) throws IOException {
        super("target/pageLayoutSpecs/" 
                + yamlFile.replace(".yaml", "").replace(".yml", "") 
                + ".spec");
        getParentFile().mkdirs();
        createNewFile();
        BufferedWriter out = new BufferedWriter(new FileWriter(this));
        out.write(spec(pageUI));
        out.close();
    }
    
    String spec(YamlPage pageUI){
        String specContent = "@objects\n";
        String objectIndent = "    ";
        if(pageUI.yamlElements.containsKey("container")){
            objectIndent = "        ";
        }
        for(String elementName : pageUI.yamlElements.keySet()){
            if(elementName.equals("container")){
                specContent += "    " + elementName
                        + "            " + pageUI.yamlElements.get(elementName).findBy
                        + "            " + pageUI.yamlElements.get(elementName).locator
                        + "\n";                
            }else{
                specContent += objectIndent + elementName
                        + "            " + pageUI.yamlElements.get(elementName).findBy
                        + "            " + pageUI.yamlElements.get(elementName).locator
                        + "\n";
            }
        }
        specContent += "\n\n" + buildTestSpecs(pageUI.page, pageUI.yamlElements.containsKey("container"));
        return specContent;
    }
    
    String buildTestSpecs(Map page, Boolean inContainer){
        if(!page.containsKey("displaySpecs")){
            return "";
        }
        
        String testSpecs = "= section =\n";
        Map<String, Object> displaySpecsMap = (Map)page.get("displaySpecs");
        
        for(String tag:displaySpecsMap.keySet()){
            if(tag.equals("all")){
                testSpecs += "    @on *\n";
            }else{
                testSpecs += "    @on " + tag + "\n";
            }
                
            Map<String, Object> elementSpecs = (Map)displaySpecsMap.get(tag);
            for(String elementName:elementSpecs.keySet()){
                String elementLogicalName = elementName;
                if(inContainer){
                    elementLogicalName = "container." + elementName;
                }
                testSpecs += "        " + elementLogicalName + ":\n";

                List<String> specs = (List)elementSpecs.get(elementName);
                for(String specEntry:specs){
                    testSpecs += "            " + specEntry + "\n";
                }
            }
            
            testSpecs += "\n\n";
        }
        
        return testSpecs;
    }
}
