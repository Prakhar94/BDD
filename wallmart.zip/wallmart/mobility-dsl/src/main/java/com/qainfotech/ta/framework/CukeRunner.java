package com.qainfotech.ta.framework;


import cucumber.runtime.ClassFinder;
import cucumber.runtime.Runtime;
import cucumber.runtime.RuntimeOptions;
import cucumber.runtime.io.MultiLoader;
import cucumber.runtime.io.ResourceLoader;
import cucumber.runtime.io.ResourceLoaderClassFinder;

import java.util.ArrayList;
import java.util.List;

import java.io.IOException;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
/**
 *
 * @author Ramandeep <RamandeepSingh@QAInfoTech.com>
 */
public class CukeRunner implements Runnable{
    private CountDownLatch latch;
    String feature;
    Runtime runtime;
    public CukeRunner(String feature, CountDownLatch latch){
        this.latch = latch;
        this.feature = feature;
        List<String> args = new ArrayList();
        args.add("--plugin");
        args.add("html:target/" + feature + "/report.html");
        args.add("--plugin");
        args.add("json:target/" + feature + "/report.json");
        args.add("--plugin");
        args.add("pretty");
        args.add("features/" + feature + ".feature");
        
        ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
        RuntimeOptions runtimeOptions = new RuntimeOptions(args);
        ResourceLoader resourceLoader = new MultiLoader(classLoader);
        ClassFinder classFinder = new ResourceLoaderClassFinder(resourceLoader, classLoader);
        runtime = new Runtime(resourceLoader, classFinder, classLoader, runtimeOptions);
    }
    
    public void run(){
        System.out.println("Running feature " +  feature );
        try{
            runtime.run();
        }catch (IOException e){
            e.printStackTrace();
        }
        System.out.println(runtime.exitStatus());
        System.out.println("Feature " + feature + " executed.");
        latch.countDown();
    }
    
//    public static void executeFeatures(List<String> features, Integer parallelThreads) throws Exception{
//        CountDownLatch latch = new CountDownLatch(features.size());
//        ExecutorService executor = Executors.newFixedThreadPool(parallelThreads);
//        for(String feature:features){
//            executor.submit(new CukeRunner(feature, latch));
//        }
//        latch.await();
//    }
    
}
