package com.qainfotech.ta.framework.pagefactory;

import com.qainfotech.ta.framework.TestSession;
import com.jcabi.aspects.Loggable;
/**
 *
 * @author Ramandeep <RamandeepSingh@QAInfoTech.com>
 */
@Loggable
public class MobileWebViewPage extends Page{
    
    public MobileWebViewPage(TestSession session, String pageYamlFile) throws Exception{
        super(session, pageYamlFile);
    }
    
    @Override
    public Boolean isDisplayed(){
        switchToPageContext();
        return super.isDisplayed();
    }
    
}
