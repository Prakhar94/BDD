package com.qainfotech.ta.framework;

import org.openqa.selenium.WebDriver;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileDriver;
import java.util.Map;
import java.util.HashMap;
import org.yaml.snakeyaml.Yaml;
import org.apache.log4j.Logger;

import java.net.MalformedURLException;

import java.util.Properties;
import org.apache.log4j.PropertyConfigurator;
import java.io.IOException;

import java.io.FileInputStream;
import org.apache.commons.io.IOUtils;
import java.io.PrintWriter;
import org.json.JSONArray;

import java.util.List;
import java.util.ArrayList;

import com.qainfotech.ta.framework.pagefactory.MobileWebViewPage;



/**
 *
 * @author Ramandeep <RamandeepsSingh@QAInfoTech.com>
 */
public class TestSession {
    
    public WebDriver driver;
//    public MobileDriver app;
    public Map<String, Object> config;
//    public Map<String, WikiPageData> testData;
    public static Logger logger;
    public String testConfiguration;
    
    public TestSession() throws MalformedURLException, IOException{
        System.setProperty("org.slf4j.simpleLogger.logFile", "target/testactivity.log");
        config = new HashMap();
        Yaml yaml = new Yaml();
        config = (Map<String, Object>) yaml
				.load(getClass().getClassLoader().getResourceAsStream("testConfiguration.yaml"));
        
        Properties props = new Properties();
        props.load(getClass().getResourceAsStream("/log4j.properties"));
        PropertyConfigurator.configure(props);
        
        logger = Logger.getLogger("TestActivity");
        logger.info("Starting Test Session...");
        logger.info("Initializing Test Data...");
        testConfiguration = config.get("test-configuration").toString();
        logger.info("Launching Test Configuration: " + testConfiguration + " ...");
        
        driver = new ConfigurationRegistry().getDriver(config);
    }
    
    public TestSession(Map<String, Object> options) throws MalformedURLException, IOException{
        System.setProperty("org.slf4j.simpleLogger.logFile", "target/testactivity.log");
        config = new HashMap();
        Yaml yaml = new Yaml();
        config = (Map<String, Object>) yaml
				.load(getClass().getClassLoader().getResourceAsStream("testConfiguration.yaml"));
        
        Properties props = new Properties();
        props.load(getClass().getResourceAsStream("/log4j.properties"));
        PropertyConfigurator.configure(props);
        
        logger = Logger.getLogger("TestActivity");
        
        logger.info("Starting Test Session...");
        logger.info("Initializing Test Data...");
        testConfiguration = config.get("test-configuration").toString();
        logger.info("Launching Test Configuration: " + testConfiguration + " ...");
        
        driver = new ConfigurationRegistry().getDriver(config, options);
    }
    
    public void quit() throws Exception{
        if(driver != null){
            try{
                ((AppiumDriver)driver).context("NATIVE_APP");
                ((AppiumDriver)driver).closeApp();
            } catch(Exception e){}
            driver.quit();
            Thread.sleep(2000);
        }
    
        
        // parse activity logs
//        FileInputStream inputStream = new FileInputStream("target/testactivity.log");
//        Map<String, List<Float>> capRaw = new HashMap();
//        try {
//            String rawLog = IOUtils.toString(inputStream);
//            
//            int c = 0;
//            for(String log:rawLog.split("\n")){
//                if(c!=0){
//                    if(log.contains("[main] INFO ")){
//                        String time = log.split(" ")[log.split(" ").length-1];
//                        Float timeInSeconds = Float.NaN;
//                        if(time.endsWith("ms")){
//                            timeInSeconds = Float.parseFloat(time.replace("ms", ""))/1000;
//                        }else if(time.endsWith("µs")){
//                            timeInSeconds = Float.parseFloat(time.replace("µs", ""))/(1000*1000);
//                        }else if(time.endsWith("s")){
//                            timeInSeconds = Float.parseFloat(time.replace("s", ""));
//                        }
//                        String method = log.split("INFO ")[1].split(": ")[0].split("\\(")[0].replace(" - ", "");
//                        if(capRaw.containsKey(method)){
//                            capRaw.get(method).add(timeInSeconds);
//                        }else{
//                            List<Float> times = new ArrayList();
//                            times.add(timeInSeconds);
//                            capRaw.put(method, times);
//                        }
//                    }
//                }
//                c++;
//            }
//            
//        } finally {
//            inputStream.close();
//        }
//        
//        List<Map<String, Object>> cap = new ArrayList();
//        /**
//         * [{
//         *     "actionName": String,
//         *     "averageExecutionTime" : Double,
//         *     "executionTimes" : [Double]
//         * }
//         * ]
//         */ 
//        String js = "";
//        for(String method:capRaw.keySet()){
//            Double sum = 0.0;
//            List<Float> executionTimes = capRaw.get(method);
//            String actionName = method;
//            for(Float time:capRaw.get(method)){
//                sum += time;
//            }
//            Double averageExecutionTime = sum/capRaw.get(method).size();
//            Map<String, Object> methodReading = new HashMap();
//            methodReading.put("actionName", actionName);
//            methodReading.put("averageExecutionTime", averageExecutionTime);
//            methodReading.put("executionTimes", executionTimes);
//            cap.add(methodReading);
//            js += "\n\n" + chartJS(method, executionTimes);
//        }
//        PrintWriter writer = new PrintWriter("target/actionReadingsChart.js", "UTF-8");
//        writer.println(js);
//        writer.close();
    }
    
    private String chartJS(String action, List<Float> data){
        String name = action.replace(".", "-").replace("#", "_");
        String values = "";
        String label = action.split("\\.")[action.split("\\.").length-1];
        Integer width = 500;
        if(data.size()*20 > width){
            width = data.size()*20;
        }
        for(Float d:data){
            values += ", "+d;
        }
        if(values.startsWith(", ")){
            values = values.replaceFirst(", ", "");
        }
        return "var elm = $('<div id=\""+name+"\" width=\""+data.size()*20+"px\" height=\"200px\"></div>').appendTo('body');\n" +
"            c3.generate({\n" +
"                bindto: '#' + elm.attr('id'),\n" +
"                data: {\n" +
"                  columns: [\n" +
"                    ['"+label+"', "+values+"]\n" +
"                  ],\n" +
"                  type: 'bar'\n" +
"                },\n" +
"                bar: {\n" +
"                  width: 10\n" +
"                },\n" +
"                axis: {\n" +
"                  x: {\n" +
"                    tick: {\n" +
"                      fit: false,\n" +
"                      count: "+(data.size()+2)+"\n" +
"                    }\n" +
"                  }\n" +
"                },\n" +
"                size: {\n" +
"                   width: "+ (width) +",\n" +
"                   height: 200,\n" +                
"                }\n" +
"            });";
    }
}