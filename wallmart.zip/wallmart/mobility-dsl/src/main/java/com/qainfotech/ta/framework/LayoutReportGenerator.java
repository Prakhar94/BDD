package com.qainfotech.ta.framework;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import org.apache.commons.io.FileUtils;

/**
 *
 * @author Ramandeep <RamandeepsSingh@QAInfoTech.com>
 */
public class LayoutReportGenerator {
    
    public static void main(String args[]) throws IOException{
        
        String jsonContent = "";
        File folder = new File ("./target/testactivity/layout-tests/json");
        if(folder.exists()){
            for(File file:folder.listFiles()){
                jsonContent += FileUtils.readFileToString(file, "UTF-8") + ",";
            }
            jsonContent = "var reportData = { \"tests\": [ " + jsonContent + "]}";
            File jsonFile = new File("./target/testactivity/layout-tests/combined.js");
            jsonFile.createNewFile();
            BufferedWriter out = new BufferedWriter(new FileWriter(jsonFile));
            out.write(jsonContent);
            out.close();

            createCombinedReportHtml();
        }
    }
    
    static void createCombinedReportHtml() throws IOException {
        String html = "<html>\n" +
"    <head>\n" +
"        <title>Layout Check Reports</title>\n" +
"        <link rel=\"stylesheet\" type=\"text/css\" href=\"report.css\"></link>\n" +
"        <link rel=\"stylesheet\" type=\"text/css\" href=\"tablesorter.css\"></link>\n" +
"        <script src=\"jquery-1.11.2.min.js\"></script>\n" +
"        <script src=\"handlebars-v2.0.0.js\"></script>\n" +
"        <script src=\"tablesorter.js\"></script>\n" +
"        <script src=\"galen-report.js\"></script>\n" +
"        <script src=\"combined.js\"></script>"+
"        <script>\n" +
"            $(function () {\n" +
"                var galenReport = createGalenTestOverview();\n" +
"                galenReport.renderTestsTable(\"tests-table\", reportData);\n" +
"                galenReport.renderGroupsTable(\"groups-table\", reportData);\n" +
"\n" +
"                window.onhashchange = function () {\n" +
"                    galenReport.handleHash(window.location.hash.substr(1));\n" +
"                };\n" +
"\n" +
"                galenReport.handleHash(window.location.hash.substr(1));\n" +
"            });\n" +
"        </script>\n" +
"    </head>\n" +
"    <body>\n" +
"\n" +
"\n" +
"        <div class=\"tests-overview\">\n" +
"            <h2>Layout Test Report</h2>\n" +
"            <div class=\"tabs\">\n" +
"                <a class=\"tab tab-tests\" href=\"#tests\">Tests</a>\n" +
"                <a class=\"tab tab-groups\" href=\"#groups\">Groups</a>\n" +
"            </div>\n" +
"            <div id=\"tests-table\">\n" +
"            </div>\n" +
"            <div id=\"groups-table\">\n" +
"            </div>\n" +
"\n" +
"            <script id=\"tests-table-tpl\" type=\"text/x-handlebars-template\">\n" +
"                <table class=\"tests tablesorter\">\n" +
"                    <thead>\n" +
"                        <tr>\n" +
"                            <th>Test</th>\n" +
"                            <th>Passed</th>\n" +
"                            <th>Failed</th>\n" +
"                            <th>Warnings</th>\n" +
"                            <th>Total</th>\n" +
"                            <th>Groups</th>\n" +
"                            <th>Started</th>\n" +
"                            <th>Duration</th>\n" +
"                            <th></th>\n" +
"                        </tr>\n" +
"                    </thead>\n" +
"                    <tbody>\n" +
"                        {{#each tests}}\n" +
"                        <tr data-groups=\"{{groups}}\">\n" +
"                            <td class=\"suite-link\">\n" +
"                                <a href=\"{{testId}}.html\">{{name}}</a>\n" +
"                            </td>\n" +
"                            <td class=\"status passed\">{{statistic.passed}}</td>\n" +
"                            <td class=\"status failed\">{{statistic.errors}}</td>\n" +
"                            <td class=\"status warnings\">{{statistic.warnings}}</td>\n" +
"                            <td class=\"status total\">{{statistic.total}}</td>\n" +
"                            <td class=\"tags\">{{formatGroupsPretty groups}}</td>\n" +
"                            <td class=\"time\">{{formatDateTime startedAt}}</td>\n" +
"                            <td class=\"time\">{{formatDurationHumanReadable duration}}</td>\n" +
"                            <td class=\"progressbar\">\n" +
"                                {{renderProgressBar statistic}}\n" +
"                            </td>\n" +
"                        </tr>\n" +
"                        {{/each}}\n" +
"                    </tbody>\n" +
"                </table>\n" +
"            </script>\n" +
"            <script id=\"groups-table-tpl\" type=\"text/x-handlebars-template\">\n" +
"                <table class=\"groups tablesorter\">\n" +
"                    <thead>\n" +
"                        <tr>\n" +
"                            <th>Group</th>\n" +
"                            <th>Passed</th>\n" +
"                            <th>Failed</th>\n" +
"                            <th>Tests</th>\n" +
"                            <th></th>\n" +
"                        </tr>\n" +
"                    </thead>\n" +
"                    <tbody>\n" +
"                        {{#each this}}\n" +
"                        <tr>\n" +
"                            <td class=\"group-link\">\n" +
"                                <a href=\"#tests|grouped|{{name}}\">{{name}}</a>\n" +
"                            </td>\n" +
"                            <td class=\"status passed\">{{passed}}</td>\n" +
"                            <td class=\"status failed\">{{failed}}</td>\n" +
"                            <td class=\"status total\">{{tests}}</td>\n" +
"                            <td class=\"progressbar\">\n" +
"                                {{renderGroupsProgressBar this}}\n" +
"                            </td>\n" +
"                        </tr>\n" +
"                        {{/each}}\n" +
"                    </tbody>\n" +
"                </table>\n" +
"            </script>\n" +
"        </div>\n" +
"    </body>\n" +
"</html>\n" +
"";
        File htmlFile = new File("./target/testactivity/layout-tests/index.html");
        htmlFile.createNewFile();
        BufferedWriter out = new BufferedWriter(new FileWriter(htmlFile));
        out.write(html);
        out.close();
        
    }
}
