package com.qainfotech.ta.framework;

import java.util.Map;
import java.util.HashMap;
import java.util.List;
import org.yaml.snakeyaml.Yaml;
import java.io.File;
import java.net.URL;
import java.net.MalformedURLException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.MobileDriver;

/**
 *
 * @author Ramandeep <RamandeepSingh@QAInfoTech.com>
 */
public class ConfigurationRegistry {
    
    Map<String, Object> registry;
    
    public ConfigurationRegistry(){
        registry = (Map<String, Object>) new Yaml().load(getClass()
                .getClassLoader().getResourceAsStream("configurationRegistry.yaml"));
    }
    
    public WebDriver getDriver(Map<String, Object>config) throws MalformedURLException{
        Map<String, Object> options = new HashMap();
        return getDriver(config, options);
    }
    
    public WebDriver getDriver(Map<String, Object>config, Map<String,
            Object> options) throws MalformedURLException{
        String testConfiguration = config.get("test-configuration").toString();
        if(options.containsKey("TEST_CONFIGURATION")){
            testConfiguration = options.get("TEST_CONFIGURATION").toString();
        }
        
        Map<String, String> configRegistry = (Map<String, String>)registry.get(testConfiguration);
        
        WebDriver driver = null;
        
        switch(configRegistry.get("browser")){
            case "app":
                if(configRegistry.get("mode").equalsIgnoreCase("remote")){
                    if(configRegistry.get("os").equalsIgnoreCase("android")){
                        DesiredCapabilities capabilities = new DesiredCapabilities();
                        Object testApps = config.get("test_app");
                        Object appConfig = ((Map<String, String>)testApps).get("android");
                        String activity = ((Map<String,String>)appConfig).get("activity");
                        String appName = ((Map<String,String>)appConfig).get("file");
                        String appPath = configRegistry.get("appFilePath") + "/" + appName;
                        
                        capabilities.setCapability("app", appPath);
                        capabilities.setCapability("appActivity", activity);
                        capabilities.setCapability("newCommandTimeout", 60000);
                        capabilities.setCapability("udid", configRegistry.get("deviceId"));
                        
                        if(options.containsKey("APPIUM_APP_NO_RESET")){
                            capabilities.setCapability("noReset", options.get("APPIUM_APP_NO_RESET"));
                        }
                        
                        capabilities.setCapability("deviceName",configRegistry.get("deviceName"));
                        driver = new AndroidDriver(new URL(configRegistry.get("server")), capabilities);
                    }else{
                        
                    }
                }else{
                    if(configRegistry.get("os").equalsIgnoreCase("android")){
                        DesiredCapabilities capabilities = new DesiredCapabilities();
                        Object testApps = config.get("test_app");
                        Object appConfig = ((Map<String, String>)testApps).get("android");
                        String activity = ((Map<String,String>)appConfig).get("activity");
                        String appName = ((Map<String,String>)appConfig).get("file");
                        String appPath = configRegistry.get("appFilePath") + "/" + appName;
                        
                        capabilities.setCapability("app", appPath);
                        capabilities.setCapability("appActivity", activity);
                        capabilities.setCapability("newCommandTimeout", 60000);
                        capabilities.setCapability("udid", configRegistry.get("deviceId"));
                        
                        if(options.containsKey("APPIUM_APP_NO_RESET")){
                            capabilities.setCapability("noReset", options.get("APPIUM_APP_NO_RESET"));
                        }
                        
                        capabilities.setCapability("deviceName",configRegistry.get("deviceName"));
                        driver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
                    }else{
                        
                    }
                }
                break;
            case "chrome":
                if(configRegistry.get("mode").equalsIgnoreCase("remote")){
                    
                }else{
                    driver = new ChromeDriver();
                }
                break;
            default:
                driver = new ChromeDriver();
        }
        return driver;
    }
}
