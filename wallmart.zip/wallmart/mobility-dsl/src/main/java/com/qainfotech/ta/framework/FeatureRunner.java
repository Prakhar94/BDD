package com.qainfotech.ta.framework;



import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import java.util.List;

/**
 *
 * @author Ramandeep <RamandeepSingh@QAInfoTech.com>
 */
public class FeatureRunner {
    public static void executeFeatures(List<String> features, Integer parallelThreads) throws InterruptedException{
        CountDownLatch latch = new CountDownLatch(features.size());
        ExecutorService executor = Executors.newFixedThreadPool(parallelThreads);
        for(String feature:features){
            executor.submit(new CukeRunner(feature, latch));
        }
        latch.await();
    }
}
