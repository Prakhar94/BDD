package com.qainfotech.ta.framework;

//package com.qainfotech.ta.automation;
//
//import org.testng.annotations.*;
//
//import com.qainfotech.ta.automation.framework.TestSession;
//import org.apache.log4j.Logger;
//import java.lang.reflect.Method;
//import org.testng.ITestResult;
//import org.apache.commons.io.FileUtils;
//import java.io.File;
//import org.openqa.selenium.TakesScreenshot;
//import org.openqa.selenium.OutputType;
//
///**
// *
// * @author Ramandeep <RamandeepsSingh@QAInfoTech.com>
// */
//public class TestCase {
//    
//    TestSession session;
//    Logger logger;
//    
//    @BeforeClass
//    public void __setUpClass() throws Exception {
//        logger = Logger.getLogger(this.getClass());
//        session = new TestSession("testConfiguration.yaml", logger);
//    }
//
//    @AfterClass
//    public void ztearDownClass() throws Exception {
//        session.quit();
//    }
//
//    @BeforeMethod
//    public void __setUpMethod(Method method) throws Exception {
//        session.log.info("Entering test method: " + method.getName());
//    }
//
//    @AfterMethod
//    public void __tearDownMethod(Method method) throws Exception {
//        session.log.info("Exiting test method: " + method.getName());
//    }
//    
//    @AfterMethod
//    public void takeScreenShotOnFailure(ITestResult testResult) throws Exception{
//        if (testResult.getStatus() == ITestResult.FAILURE){
//            session.log.info("Test method failed : " + testResult.getMethod().getMethodName());
//            File scrFile = ((TakesScreenshot)session.driver).getScreenshotAs(OutputType.FILE);
//            String fileName = this.getClass().getSimpleName()
//                    + "-" + testResult.getMethod().getMethodName()
//                    + "-" + (System.currentTimeMillis());
//            session.log.info("Screenshot captured: target/testactivity/failurescreenshots/"+fileName+".jpg");
//            FileUtils.copyFile(scrFile, new File("target/testactivity/failurescreenshots/"+fileName+".jpg"));
//        }
//    }
//}