package com.qainfotech.ta.testrailrunner;

/**
 *
 * @author Ramandeep <ramandeepsingh@qainfotech.com>
 */
public class TestRailApiClientException extends Exception{
    
    public TestRailApiClientException(String message){
        super(message);
    }
    
}
