package com.qainfotech.ta.testrailrunner;

/**
 *
 * @author Ramandeep <ramandeepsingh@qainfotech.com>
 */
public class GoogleSheetHandler {
    
    public GoogleSheetHandler(){
        
    }
}
