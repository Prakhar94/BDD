package com.java.mobility.tests;

import cucumber.api.java.en.*;
import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;

import java.util.Map;
import java.util.HashMap;

import static org.assertj.core.api.Assertions.*;

import com.qainfotech.ta.framework.TestSession;

import com.walmart.mobility.test.dsl.mobileui.myproductivity.*;
import com.walmart.mobility.test.dsl.mobileui.applications.*;
import com.walmart.mobility.test.dsl.mobileui.applications.availability.*;


/**
 *
 * @author Ramandeep <RamandeepSingh@QAInfoTech.com>
 */
public class StepDefinitions {

    TestSession session;
    LandingPage myProductivityLandingPage;
    LandingPageErrorPrompt myProductivityLandingPageErrorPrompt;
    ApplicationMenu applicationMenu;
    AvailabilityApp availabilityApp;
    HRIS_HomePage homePage;
    WebServices webService;
    
    @Before
    public void setUp() throws Exception{
        Map<String, Object> options = new HashMap();
        options.put("APPIUM_APP_NO_RESET", true);
        session = new TestSession(options);        
    }
    
    @After
    public void tearDown() throws Exception{
        session.quit();
    }
    

//    @Given("^I launch the HRIS Application$")
//    public void i_launch_the_HRIS_Application() throws Throwable {
//        // Write code here that turns the phrase above into concrete actions
//        homePage = new HRIS_HomePage(session);
//    }
//
//    @Then("^I check for the title$")
//    public void i_check_for_the_title() throws Throwable {
//        // Write code here that turns the phrase above into concrete actions
//        homePage.verifyHomePage();
//    }
//
//    @Then("^I check for all the Tabs$")
//    public void i_check_for_all_the_Tabs() throws Throwable {
//        // Write code here that turns the phrase above into concrete actions
//        homePage.verifyTabs();
//    }
//
//    @When("^I click Side Navigation Menu$")
//    public void i_click_Side_Navigation_Menu() throws Throwable {
//        // Write code here that turns the phrase above into concrete actions
//        homePage.clickSideNavButton();
//    }

    
    @Given("^I launch the QAIT application$")
    public void i_launch_the_QAIT_application() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
      webService = new WebServices(session);
    }

    @When("^I input my valid credentials$")
    public void i_input_my_valid_credentials() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
       homePage.selectHRISlogin();
       
    }

    @Then("^I see the Timesheet tab$")
    public void i_see_the_Timesheet_tab() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
      
    }

    @Then("^i select the Timesheet tab$")
    public void i_select_the_Timesheet_tab() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
       
    }

    @Then("^view the timesheet information for (\\d+) dates$")
    public void view_the_timesheet_information_for_dates(int arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
      
    }




}